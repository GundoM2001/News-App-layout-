import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: TechPage());
  }
}

var indexclicked = 0;

class TechPage extends StatefulWidget {
  @override
  _TechPageState createState() => _TechPageState();
}

class _TechPageState extends State<TechPage> {
  final pages = [
    Center(
      child: ListView(children: [
        const SizedBox(
          height: 5,
        ),
        Material(
          elevation: 7,
          child: ListTile(
            leading: const Icon(
              Icons.newspaper,
              color: Color.fromARGB(255, 105, 165, 255),
              size: 40,
            ),
            title: const Text(
              'Elon Musk\'s pro-Russian peace deal is \'Classic Putin\' and there\'s a clue about his role - Expert',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            trailing: Image.network(
                'https://www.kxan.com/wp-content/uploads/sites/40/2022/03/putin-musk.png?w=960&h=540&crop=1',
                height: 100,
                width: 100),
            subtitle: Row(children: const [
              Icon(
                Icons.share,
                color: Colors.grey,
                size: 30,
              ),
              SizedBox(
                width: 20,
              ),
              Icon(
                Icons.access_time,
                color: Colors.grey,
                size: 30,
              ),
              SizedBox(
                width: 20,
              ),
              Text(
                '7 hours ago',
                style: TextStyle(color: Colors.grey, fontSize: 14),
              )
            ]),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Material(
          elevation: 7,
          child: ListTile(
            leading: const Icon(
              Icons.newspaper,
              color: Color.fromARGB(255, 105, 165, 255),
              size: 40,
            ),
            title: const Text(
              'Why is South Africa shying away from digital IDs?',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            trailing: Image.network(
                'https://image-prod.iol.co.za/16x9/800/Digital-identification-is-one-of-the-most-significant-technological-developments-today-and-has-transformed-the-way-people-interact-with-public-and-private-institutions-says-the-author?source=https://xlibris.public.prod.oc.inl.infomaker.io:8443/opencontent/objects/38c5b467-9b6b-5ab2-a220-ea6055c1d1c0',
                height: 100,
                width: 100),
            subtitle: Row(children: const [
              Icon(
                Icons.share,
                color: Colors.grey,
                size: 30,
              ),
              SizedBox(
                width: 20,
              ),
              Icon(
                Icons.access_time,
                color: Colors.grey,
                size: 30,
              ),
              SizedBox(
                width: 20,
              ),
              Text(
                '1 hour ago',
                style: TextStyle(color: Colors.grey, fontSize: 14),
              )
            ]),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Material(
          elevation: 7,
          child: ListTile(
            leading: const Icon(
              Icons.newspaper,
              color: Color.fromARGB(255, 105, 165, 255),
              size: 40,
            ),
            title: const Text(
              'Chip Shortage forces Toyota to issue metal car keys in Japan',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            trailing: Image.network(
                'https://i.kinja-img.com/gawker-media/image/upload/c_fit,f_auto,g_center,pg_1,q_60,w_965/d64cf002912a9f1822c657d2bc5bc2cb.jpg',
                height: 100,
                width: 100),
            subtitle: Row(children: const [
              Icon(
                Icons.share,
                color: Colors.grey,
                size: 30,
              ),
              SizedBox(
                width: 20,
              ),
              Icon(
                Icons.access_time,
                color: Colors.grey,
                size: 30,
              ),
              SizedBox(
                width: 20,
              ),
              Text(
                '2 days ago',
                style: TextStyle(color: Colors.grey, fontSize: 14),
              )
            ]),
          ),
        )
      ]),
    ),
    Center(
      child: ListView(
        children: [
          const SizedBox(
            height: 5,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'Red Bull backs Verstappen and boycotts Sky Sports \'indefinitely\'',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://cdn.gpblog.com/news/2022/10/30/v2_large_b288dff3e9a07b83393c5cfdff39ce72db8e73b2.jpg',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '11 hours ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'Real Madrid plotting transfer move for Arsenal\'s Gabriel Jesus next summer',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://e0.365dm.com/22/10/1600x900/skysports-gabriel-jesus-arsenal_5932605.jpg?20221016131016',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '8 hours ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'Holders Spain win FIFA U-17 Women\'s World Cup',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://images.indianexpress.com/2022/10/Spain-U-17-team.jpg',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '14 hours ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          )
        ],
      ),
    ),
    Center(
      child: ListView(
        children: [
          const SizedBox(
            height: 5,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'Crisis in South Africa shakes up politics before party election',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://cdn.primedia.co.za/primedia-broadcasting/image/upload/c_fill,h_289,w_463/wqgrazbfsgtvp6mtmyqv',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '3 days ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'Paul Pelosi attack unleashes partisan finger-pointing and sows fresh fears of political violence',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://media.cnn.com/api/v1/images/stellar/prod/221031105948-paul-pelosi-attack.jpg?c=16x9&q=h_720,w_1280,c_fill',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '4 hours ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'Multiparty democracy is in trouble in South Africa',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://cdn.24.co.za/files/Cms/General/d/10018/44feb29c9901474cb63636fef97c8a6b.jpg',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '2 days ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          )
        ],
      ),
    ),
    Center(
      child: ListView(
        children: [
          const SizedBox(
            height: 5,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'God of War: Ragnarok\'s devs say the game\'s broken street date is "so disappointing"',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://cdn.mos.cms.futurecdn.net/dT5jaPwCSERSNFrrhmtwyb-1200-80.jpg.webp',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '20 hours ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'Halloween Tragedy in Itaewon, Seoul: 151 dead, SM Entertainment\'s yearly party cancelled',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://www.pinkvilla.com/english/images/2022/10/606719490__1280*720.jpg',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '1 day ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Material(
            elevation: 7,
            child: ListTile(
              leading: const Icon(
                Icons.newspaper,
                color: Color.fromARGB(255, 105, 165, 255),
                size: 40,
              ),
              title: const Text(
                'Kendall Jenner shares picture with boyfriend Devin Booker on his 26th birthday',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              trailing: Image.network(
                  'https://www.geo.tv/assets/uploads/updates/2022-10-31/449537_8274820_updates.jpg',
                  height: 100,
                  width: 100),
              subtitle: Row(children: const [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Icon(
                  Icons.access_time,
                  color: Colors.grey,
                  size: 30,
                ),
                SizedBox(
                  width: 20,
                ),
                Text(
                  '4 hours ago',
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                )
              ]),
            ),
          )
        ],
      ),
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.lightBlue,
        title: RichText(
            text: const TextSpan(children: <TextSpan>[
          TextSpan(
              text: 'News',
              style: TextStyle(
                  color: Colors.red,
                  fontSize: 20,
                  fontWeight: FontWeight.w900)),
          TextSpan(
              text: 'App+',
              style: TextStyle(
                  color: Colors.lightBlue,
                  fontSize: 20,
                  fontWeight: FontWeight.w100))
        ])),
        backgroundColor: Colors.white,
        elevation: 7,
      ),
      body: pages[indexclicked],
      drawer: Drawer(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          DrawerHeader(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                const CircleAvatar(
                  radius: 40,
                  backgroundImage: AssetImage('assets/images/profile.jpg'),
                ),
                const SizedBox(
                  height: 10,
                ),
                Material(
                    child: RichText(
                        text: const TextSpan(children: <TextSpan>[
                  TextSpan(
                      text: 'News',
                      style: TextStyle(
                          color: Colors.red,
                          fontSize: 20,
                          fontWeight: FontWeight.w900)),
                  TextSpan(
                      text: 'App+',
                      style: TextStyle(
                          color: Colors.lightBlue,
                          fontSize: 20,
                          fontWeight: FontWeight.w100))
                ]))),
                const SizedBox(
                  height: 4,
                ),
                const Text(
                  'News on the go',
                  style: TextStyle(color: Colors.green, fontSize: 10),
                )
              ])),
          Expanded(
              child: ListView(
            padding: EdgeInsets.zero,
            children: [
              ListTile(
                onTap: (() {
                  setState(() {
                    indexclicked = 0;
                  });
                }),
                leading: Icon(
                  Icons.computer_outlined,
                  size: 40,
                  color: indexclicked == 0 ? Colors.blue : Colors.grey,
                ),
                title: Text(
                  'Tech',
                  style: TextStyle(
                      fontSize: 20,
                      color: indexclicked == 0 ? Colors.blue : Colors.grey),
                ),
              ),
              ListTile(
                onTap: (() {
                  setState(() {
                    indexclicked = 1;
                  });
                }),
                leading: Icon(
                  Icons.sports_cricket,
                  size: 40,
                  color: indexclicked == 1 ? Colors.blue : Colors.grey,
                ),
                title: Text(
                  'Sports',
                  style: TextStyle(
                      fontSize: 20,
                      color: indexclicked == 1 ? Colors.blue : Colors.grey),
                ),
              ),
              ListTile(
                onTap: (() {
                  setState(() {
                    indexclicked = 2;
                  });
                }),
                leading: Icon(
                  Icons.flag_circle_outlined,
                  size: 40,
                  color: indexclicked == 2 ? Colors.blue : Colors.grey,
                ),
                title: Text(
                  'Politics',
                  style: TextStyle(
                      fontSize: 20,
                      color: indexclicked == 2 ? Colors.blue : Colors.grey),
                ),
              ),
              ListTile(
                onTap: (() {
                  setState(() {
                    indexclicked = 3;
                  });
                }),
                leading: Icon(
                  Icons.music_note_outlined,
                  size: 40,
                  color: indexclicked == 3 ? Colors.blue : Colors.grey,
                ),
                title: Text(
                  'Entertainment',
                  style: TextStyle(
                      fontSize: 20,
                      color: indexclicked == 3 ? Colors.blue : Colors.grey),
                ),
              )
            ],
          ))
        ],
      )),
    );
  }
}
